function validate(){
    var pass1 = String(document.getElementById("pass1").value);
    var pass2 = String(document.getElementById("pass2").value);
    if(pass1.length >= 8 && pass2.length >= 8){
        if(pass1 == pass2){
            alert("Passwords match");
        } else{
            alert("Passwords do not match, please retype your password");
        }
    } else{
        alert("Password is too short, please make sure it is at least 8 characters long");
    }
}

function alert_paragraph_color(){
    var paragraph = document.getElementById("paragraph");

    const borderR = document.getElementById("border_R").value;
    const borderG = document.getElementById("border_G").value;
    const borderB = document.getElementById("border_B").value;
    const borderWidth = document.getElementById("border_width").value;

    paragraph.style.borderColor = "rgb("+borderR+","+borderG+","+borderB+")";
    paragraph.style.borderWidth = String(borderWidth);

    const bgR = document.getElementById("bg_R").value;
    const bgG = document.getElementById("bg_G").value;
    const bgB = document.getElementById("bg_B").value;

    paragraph.style.backgroundColor = "rgb("+bgR+","+bgG+","+bgB+")";
}
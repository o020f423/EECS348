<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>
        <h1>EECS 348 Lab Three Practice Four</h1>

        <form action="practice4.php" method="post">
            Size of the multiplication table: <input type="text" name="size"><br>
            <input type="submit" name = "submit">
        </form>
        <?php
            if(isset($_POST["submit"])){
                $size = $_POST["size"];
                $temp = 0;
                for($i = 0; $i <= $size; $i++){
                    $temp = $size * $i;
                    echo "".$size." x ".$i." = ".$temp."<br>";
                }
            }
        ?>
    </body>
</html>
